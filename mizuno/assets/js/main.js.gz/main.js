/*
 * Change Navbar color while scrolling
*/

$(window).scroll(function(){
	handleTopNavAnimation();
});

$(window).load(function(){
	handleTopNavAnimation();
});

function handleTopNavAnimation() {
	var top=$(window).scrollTop();

	if(top>10){
		$('#site-nav').addClass('navbar-solid'); 
	}
	else{
		$('#site-nav').removeClass('navbar-solid'); 
	}
}

/*
 * Registration Form
*/

$('#registration-form').submit(function(e){
    e.preventDefault();
    
    var postForm = { //Fetch form data
            'fname'     : $('#registration-form #fname').val(),
            'lname'     : $('#registration-form #lname').val(),
            'email'     : $('#registration-form #email').val(),
            'cell'      : $('#registration-form #cell').val(),
            'handicap'   : $('#registration-form #handicap').val(),
            'uname'       : $('#registration-form #uname').val(),
            'shirt'      : $('#registration-form #shirt').val(),
            'option'   : $('#registration-form #option').val()
    };
    var subject = 'Mizuno Event registration from ' + postForm.uname;

    var name =  postForm.fname + " " + postForm.lname;
    var email =  postForm.email;
    var content =  'Name: ' + postForm.fname + " " + postForm.lname;


    var bodyTable =  '<table><tr/>';
        bodyTable = bodyTable + "<tr><td>First Name</td><td>" + postForm.fname + "</td></tr>";
        bodyTable = bodyTable + "<tr><td>Last Name</td><td>" + postForm.lname + "</td></tr>";
        bodyTable = bodyTable + "<tr><td>Email</td><td>" + postForm.email + "</td></tr>";
        bodyTable = bodyTable + "<tr><td>Cell</td><td>" + postForm.cell + "</td></tr>";
        bodyTable = bodyTable + "<tr><td>Handicap</td><td>" + postForm.handicap + "</td></tr>";
        bodyTable = bodyTable + "<tr><td>Forum name</td><td>" + postForm.uname + "</td></tr>";
        bodyTable = bodyTable + "<tr><td>Shirt Size</td><td>" + postForm.shirt + "</td></tr>";
        bodyTable = bodyTable + "<tr><td>Selection</td><td>" + postForm.option + "</td></tr>";
        bodyTable = bodyTable + '</table>';

        $.ajax({
            type      : 'POST',
            url       : 'https://mandrillapp.com/api/1.0/messages/send.json',
            data: {
                'key': 'HevupQSwtJ6rQpJOHWAguw',
                'message': {
                  'from_email': 'mizuno@mastertonsmith.uk',
                  'to': [
                      {
                        'email': 'chris@cmsdes.co.uk',
                        'name': 'Chris Masterton-Smith',
                        'type': 'to'
                      },
                    ],
                  'autotext': 'true',
                  'subject': subject,
                  'html': bodyTable,
                  }
              },             
            success : function(data){
                        $('#registration-msg .alert').html("Registration Successful");
                        $('#registration-msg .alert').removeClass("alert-danger");
                        $('#registration-msg .alert').addClass("alert-success");
                        $('#registration-msg').show();
                    },
            fail: function (data){
                                $('#registration-msg .alert').html("Registration Failed");
                                $('#registration-msg .alert').removeClass("alert-success");
                                $('#registration-msg .alert').addClass("alert-danger");
                                $('#registration-msg').show();
                            },
                        
        });

});
/*
 * SmoothScroll
*/

smoothScroll.init();



// set the date we're counting down to
var target_date = new Date('June, 25, 2016').getTime();
 
// variables for time units
var days, hours, minutes, seconds;
 
// get tag element
var countdown = document.getElementById('countdown');
 
// update the tag with id "countdown" every 1 second
setInterval(function () {
 
    // find the amount of "seconds" between now and target
    var current_date = new Date().getTime();
    var seconds_left = (target_date - current_date) / 1000;
 
    // do some time calculations
    days = parseInt(seconds_left / 86400);
    seconds_left = seconds_left % 86400;
     
    hours = parseInt(seconds_left / 3600);
    seconds_left = seconds_left % 3600;
     
    minutes = parseInt(seconds_left / 60);
    seconds = parseInt(seconds_left % 60);
     
    // format countdown string + set tag value
    countdown.innerHTML = '<span class="days">' + days +  ' <b>Days</b></span> <span class="hours">' + hours + ' <b>Hours</b></span> <span class="minutes">'
    + minutes + ' <b>Minutes</b></span> <span class="seconds">' + seconds + ' <b>Seconds</b></span>';  
 
}, 1000);